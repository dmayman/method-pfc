.. -*- coding: utf-8 -*-

:mod:`ftdi` - FTDI driver
-------------------------

.. module :: pyftdi.ftdi


Classes
~~~~~~~

.. autoclass :: Ftdi
 :members:


Exceptions
~~~~~~~~~~

.. autoexception :: FtdiError
.. autoexception :: FtdiMpsseError
.. autoexception :: FtdiFeatureError
